-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 3306
-- Database : edu
-- 
-- Part : #1
-- Date : 2018-04-09 16:00:32
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `file`
-- -----------------------------
DROP TABLE IF EXISTS `file`;
CREATE TABLE `file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '上传文件ID',
  `groupId` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '上传文件组ID',
  `userId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上传人ID',
  `uri` varchar(255) NOT NULL COMMENT '文件URI',
  `mime` varchar(255) NOT NULL COMMENT '文件MIME',
  `ext` varchar(20) DEFAULT NULL COMMENT '文件类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件状态',
  `createdTime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件上传时间',
  `originName` varchar(255) NOT NULL DEFAULT '''''' COMMENT '文件原始名字',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `file`
-- -----------------------------
INSERT INTO `file` VALUES ('6', '1', '1', '2018-04-08/5ac9d76b5ba11.png', 'image/png', 'png', '0', '0', '1523177323', '');
INSERT INTO `file` VALUES ('7', '1', '1', '2018-04-08/5ac9d84e036f9.jpg', 'image/jpeg', 'jpg', '0', '0', '1523177550', '');
INSERT INTO `file` VALUES ('8', '1', '1', '2018-04-08/5ac9d8640ac1d.jpg', 'image/jpeg', 'jpg', '0', '0', '1523177572', '');
INSERT INTO `file` VALUES ('9', '1', '1', '2018-04-08/5ac9da0ae3be1.jpg', 'image/jpeg', 'jpg', '0', '0', '1523177994', '');
INSERT INTO `file` VALUES ('11', '1', '1', '2018-04-08/5ac9da5b28e0e.jpeg', 'image/jpeg', 'jpeg', '0', '0', '1523178075', '');
INSERT INTO `file` VALUES ('12', '1', '1', '2018-04-08/5ac9daea2d2df.jpg', 'image/jpeg', 'jpg', '0', '0', '1523178218', '');
INSERT INTO `file` VALUES ('13', '1', '1', '2018-04-08/5ac9dba39402e.jpg', 'image/jpeg', 'jpg', '0', '0', '1523178403', '');
INSERT INTO `file` VALUES ('14', '1', '1', '2018-04-08/5ac9dbbb09167.jpg', 'image/jpeg', 'jpg', '0', '0', '1523178427', '');
INSERT INTO `file` VALUES ('15', '1', '1', '2018-04-08/5ac9dc3fa1e24.jpg', 'image/jpeg', 'jpg', '0', '0', '1523178559', '');
INSERT INTO `file` VALUES ('16', '1', '1', '2018-04-08/5ac9dced9877c.jpeg', 'image/jpeg', 'jpeg', '0', '0', '1523178733', '');
INSERT INTO `file` VALUES ('17', '1', '1', '2018-04-08/5ac9dd4286f65.jpg', 'image/jpeg', 'jpg', '0', '0', '1523178818', '');
INSERT INTO `file` VALUES ('18', '1', '1', '2018-04-08/5ac9de307c7f1.jpeg', 'image/jpeg', 'jpeg', '0', '0', '1523179056', '');
INSERT INTO `file` VALUES ('19', '1', '1', '2018-04-08/5ac9de5709124.jpg', 'image/jpeg', 'jpg', '0', '0', '1523179095', '');
INSERT INTO `file` VALUES ('20', '1', '1', '2018-04-08/5ac9de94574f7.jpg', 'image/jpeg', 'jpg', '0', '0', '1523179156', '');
INSERT INTO `file` VALUES ('21', '1', '1', '2018-04-08/5ac9dedd11d39.jpeg', 'image/jpeg', 'jpeg', '0', '0', '1523179229', '');
INSERT INTO `file` VALUES ('22', '1', '1', '2018-04-08/5ac9deef4f90a.jpg', 'image/jpeg', 'jpg', '0', '0', '1523179247', '');
INSERT INTO `file` VALUES ('23', '1', '1', '2018-04-08/5ac9dfc3534f2.jpeg', 'image/jpeg', 'jpeg', '0', '0', '1523179459', '');
INSERT INTO `file` VALUES ('24', '1', '1', '2018-04-08/5ac9e00c741d8.jpeg', 'image/jpeg', 'jpeg', '0', '0', '1523179532', '');
INSERT INTO `file` VALUES ('25', '1', '1', '2018-04-08/5ac9e07698112.jpeg', 'image/jpeg', 'jpeg', '0', '0', '1523179638', '');
INSERT INTO `file` VALUES ('26', '1', '1', '2018-04-09/5acabd1d41f2d.png', 'image/png', 'png', '0', '0', '1523236125', '');
INSERT INTO `file` VALUES ('27', '1', '1', '2018-04-09/5acac1d3cb958.jpg', 'image/jpeg', 'jpg', '0', '0', '1523237331', '');
INSERT INTO `file` VALUES ('28', '1', '1', '2018-04-09/5acac218220f3.png', 'image/png', 'png', '0', '0', '1523237400', '');
INSERT INTO `file` VALUES ('29', '1', '1', '2018-04-09/5acac24192ab1.jpeg', 'image/jpeg', 'jpeg', '0', '0', '1523237441', '');
INSERT INTO `file` VALUES ('30', '1', '1', '2018-04-09/5acad836f04b6.jpg', 'image/jpeg', 'jpg', '286435', '0', '1523243062', '');
INSERT INTO `file` VALUES ('31', '1', '1', '2018-04-09/5acad91c9b693.jpeg', 'image/jpeg', 'jpeg', '3620023', '0', '1523243292', '14 (1).jpeg');

-- -----------------------------
-- Table structure for `file_group`
-- -----------------------------
DROP TABLE IF EXISTS `file_group`;
CREATE TABLE `file_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '上传文件组ID',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '上传文件组名称',
  `code` varchar(255) NOT NULL COMMENT '上传文件组编码',
  `auth` tinyint(3) NOT NULL DEFAULT '1' COMMENT '文件组文件权限：（0x111<-->Delete-Write-Read）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `file_group`
-- -----------------------------
INSERT INTO `file_group` VALUES ('1', '默认文件组', 'default', '1');

-- -----------------------------
-- Table structure for `log`
-- -----------------------------
DROP TABLE IF EXISTS `log`;
CREATE TABLE `log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '系统日志ID',
  `userId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '操作人ID',
  `module` varchar(32) NOT NULL COMMENT '日志所属模块',
  `action` varchar(32) NOT NULL COMMENT '日志所属操作类型',
  `message` text NOT NULL COMMENT '日志内容',
  `data` text COMMENT '日志数据',
  `ip` varchar(255) NOT NULL COMMENT '日志记录IP',
  `createdTime` int(10) unsigned NOT NULL COMMENT '日志发生时间',
  `level` char(10) NOT NULL COMMENT '日志等级',
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `log`
-- -----------------------------
INSERT INTO `log` VALUES ('27', '1', 'login', 'login', '用户admin在2018-04-06 20:07:30登录系统', '', '0.0.0.0', '1523016450', 'info');
INSERT INTO `log` VALUES ('28', '1', 'login', 'login', '用户admin在2018-04-06 23:02:55登录系统', '', '0.0.0.0', '1523026975', 'info');
INSERT INTO `log` VALUES ('29', '1', 'login', 'login', '用户admin在2018-04-07 08:45:47登录系统', '', '0.0.0.0', '1523061947', 'info');
INSERT INTO `log` VALUES ('30', '1', 'login', 'login', '用户admin在2018-04-07 09:54:07登录系统', '', '0.0.0.0', '1523066047', 'info');
INSERT INTO `log` VALUES ('31', '1', 'login', 'login', '用户admin在2018-04-07 11:01:50登录系统', '', '0.0.0.0', '1523070110', 'info');
INSERT INTO `log` VALUES ('32', '1', 'login', 'login', '用户admin在2018-04-07 15:29:11登录系统', '', '0.0.0.0', '1523086151', 'info');
INSERT INTO `log` VALUES ('33', '1', 'login', 'login', '用户admin在2018-04-07 15:33:17登录系统', '', '0.0.0.0', '1523086397', 'info');
INSERT INTO `log` VALUES ('34', '1', 'login', 'login', '用户admin在2018-04-07 16:24:20登录系统', '', '0.0.0.0', '1523089460', 'info');
INSERT INTO `log` VALUES ('35', '1', 'login', 'login', '用户admin在2018-04-07 16:24:53登录系统', '', '127.0.0.1', '1523089493', 'info');
INSERT INTO `log` VALUES ('36', '1', 'login', 'login', '用户admin在2018-04-07 19:04:43登录系统', '', '127.0.0.1', '1523099083', 'info');
INSERT INTO `log` VALUES ('37', '1', 'login', 'login', '用户admin在2018-04-08 08:36:20登录系统', '', '127.0.0.1', '1523147780', 'info');
INSERT INTO `log` VALUES ('38', '1', 'login', 'login', '用户admin在2018-04-08 09:40:49登录系统', '', '127.0.0.1', '1523151649', 'info');
INSERT INTO `log` VALUES ('39', '1', 'login', 'login', '用户admin在2018-04-08 09:42:49登录系统', '', '127.0.0.1', '1523151769', 'info');
INSERT INTO `log` VALUES ('40', '1', 'login', 'login', '用户admin在2018-04-08 09:43:18登录系统', '', '127.0.0.1', '1523151798', 'info');
INSERT INTO `log` VALUES ('41', '1', 'login', 'login', '用户admin在2018-04-08 10:00:24登录系统', '', '127.0.0.1', '1523152824', 'info');

-- -----------------------------
-- Table structure for `setting`
-- -----------------------------
DROP TABLE IF EXISTS `setting`;
CREATE TABLE `setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '系统设置ID',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '系统设置名',
  `value` longblob COMMENT '系统设置值',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `setting`
-- -----------------------------
INSERT INTO `setting` VALUES ('1', 'site', 'a:4:{s:8:\"sitename\";s:34:\"“微波技术与天线”网络 \";s:8:\"subtitle\";s:34:\"“微波技术与天线”网络 \";s:5:\"email\";s:16:\"845301111@qq.com\";s:8:\"sitelogo\";s:2:\"31\";}');
INSERT INTO `setting` VALUES ('2', 'course', 'a:5:{s:4:\"send\";s:1:\"0\";s:7:\"welcome\";s:41:\"{{nickname}},欢迎加入课程{{course}}\";s:22:\"teacher_manage_student\";s:1:\"0\";s:16:\"student_download\";s:1:\"0\";s:23:\"allow_anonymous_preview\";s:1:\"0\";}');

-- -----------------------------
-- Table structure for `user`
-- -----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `nickname` varchar(64) NOT NULL DEFAULT '' COMMENT '用户名',
  `password` varchar(64) NOT NULL DEFAULT '' COMMENT '用户密码',
  `salt` varchar(32) NOT NULL DEFAULT '' COMMENT '密码SALT',
  `email` varchar(128) NOT NULL COMMENT '用户邮箱',
  `tags` varchar(255) NOT NULL DEFAULT '' COMMENT '标签',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '小头像',
  `roles` varchar(255) NOT NULL COMMENT '用户角色',
  `fileGroupId` varchar(255) DEFAULT '1' COMMENT '文件组ID',
  `locked` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否被禁止',
  `lockDeadline` int(10) NOT NULL DEFAULT '0' COMMENT '帐号锁定期限',
  `consecutivePasswordErrorTimes` int(11) NOT NULL DEFAULT '0' COMMENT '帐号密码错误次数',
  `lastPasswordFailTime` int(10) NOT NULL DEFAULT '0',
  `loginTime` int(11) NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `loginIp` varchar(64) NOT NULL DEFAULT '' COMMENT '最后登录IP',
  `loginSessionId` varchar(255) NOT NULL DEFAULT '' COMMENT '最后登录会话ID',
  `newMessageNum` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '未读私信数',
  `newNotificationNum` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '未读消息数',
  `createdIp` varchar(64) NOT NULL DEFAULT '' COMMENT '注册IP',
  `createdTime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `nickname` (`nickname`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `user`
-- -----------------------------
INSERT INTO `user` VALUES ('1', 'admin', '205470f9c2ab233f2e30ed8660aca173', 'f1a6f60fbecf35f83df358febd5f3f81', '845301110@qq.com', '', '', '', '1', '0', '0', '0', '0', '0', '', '8bd43a9f0a197a715709f16a00601589', '0', '0', '0.0.0.0', '1522916209');
